require "bit"
local vector = require 'vector'
local ffi = require("ffi")
local js = panorama['open']()
local MyPersonaAPI, LobbyAPI, PartyListAPI, FriendsListAPI, GameStateAPI = js['MyPersonaAPI'], js['LobbyAPI'], js['PartyListAPI'], js['FriendsListAPI'], js['GameStateAPI']

-- local variables for API functions. any changes to the line below will be lost on re-generation
local client_set_event_callback, ui_get, ui_set, ui_new_checkbox, ui_new_combobox, ui_new_slider, ui_reference, ui_set_visible = client.set_event_callback, ui.get, ui.set, ui.new_checkbox, ui.new_combobox, ui.new_slider, ui.reference, ui.set_visible


local notify = (function()
    local notify = {callback_registered = false, maximum_count = 7, data = {}, svg_texture = [[<svg id="Capa_1" enable-background="new 0 0 512 512" height="512" viewBox="0 0 512 512" width="512" xmlns="http://www.w3.org/2000/svg"><g><g><path d="m216.188 82.318h48.768v37.149h-48.768z" fill="#ffcbbe"/></g><g><path d="m250.992 82.318h13.964v37.149h-13.964z" fill="#fdad9d"/></g><g><ellipse cx="240.572" cy="47.717" fill="#ffcbbe" rx="41.682" ry="49.166" transform="matrix(.89 -.456 .456 .89 4.732 115.032)"/></g><g><path d="m277.661 28.697c-10.828-21.115-32.546-32.231-51.522-27.689 10.933 4.421 20.864 13.29 27.138 25.524 12.39 24.162 5.829 52.265-14.654 62.769-2.583 1.325-5.264 2.304-8.003 2.96 10.661 4.31 22.274 4.391 32.387-.795 20.483-10.504 27.044-38.607 14.654-62.769z" fill="#fdad9d"/></g><g><path d="m296.072 296.122h-111.001v-144.174c0-22.184 17.984-40.168 40.168-40.168h30.666c22.184 0 40.168 17.984 40.168 40.168v144.174z" fill="#95d6a4"/></g><g><path d="m256.097 111.78h-24.384c22.077 0 39.975 17.897 39.975 39.975v144.367h24.384v-144.367c0-22.077-17.897-39.975-39.975-39.975z" fill="#78c2a4"/></g><g><path d="m225.476 41.375c0-8.811 7.143-15.954 15.954-15.954h34.401c-13.036-21.859-38.163-31.469-57.694-21.453-19.846 10.177-26.623 36.875-15.756 60.503 12.755-.001 23.095-10.341 23.095-23.096z" fill="#756e78"/></g><g><path d="m252.677 25.421h23.155c-11.31-18.964-31.718-28.699-49.679-24.408 10.591 4.287 20.23 12.757 26.524 24.408z" fill="#665e66"/></g><g><path d="m444.759 453.15-28.194-9.144c-3.04-.986-5.099-3.818-5.099-7.014v-4.69l-2.986-8.22h-61.669l-2.986 8.22v34.22c0 8.628 6.994 15.622 15.622 15.622h81.993c5.94 0 10.755-4.815 10.755-10.755v-8.008c.001-4.662-3.002-8.793-7.436-10.231z" fill="#aa7a63"/></g><g><path d="m444.759 453.15-28.194-9.144c-3.04-.986-5.099-3.818-5.099-7.014v-4.69l-2.986-8.22h-25.91v12.911c0 3.196 2.059 6.028 5.099 7.014l28.194 9.144c4.434 1.438 7.437 5.569 7.437 10.23v8.008c0 5.94-4.815 10.755-10.755 10.755h28.896c5.94 0 10.755-4.815 10.755-10.755v-8.008c0-4.662-3.003-8.793-7.437-10.231z" fill="#986b54"/></g><g><path d="m343.827 344.798v87.505h67.64v-123.053c0-20.65-16.74-37.39-37.39-37.39h-189.006v33.212c0 19.014 15.414 34.428 34.428 34.428h119.03c2.926 0 5.298 2.372 5.298 5.298z" fill="#5766cb"/></g><g><path d="m382.571 309.25v123.052h28.896v-123.052c0-20.65-16.74-37.39-37.39-37.39h-28.896c20.65 0 37.39 16.74 37.39 37.39z" fill="#3d4fc3"/></g><g><g><path d="m437.268 512h-108.548c-8.244 0-14.928-6.684-14.928-14.928v-107.221c0-11.247-9.15-20.399-20.398-20.399h-123.543c-8.244 0-14.928-6.684-14.928-14.928v-150.17h-22.748c-8.244 0-14.928-6.684-14.928-14.928s6.684-14.928 14.928-14.928h37.676c8.244 0 14.928 6.684 14.928 14.928v150.17h108.616c27.71 0 50.254 22.545 50.254 50.255v92.293h93.619c8.244 0 14.928 6.684 14.928 14.928s-6.684 14.928-14.928 14.928z" fill="#756e78"/></g></g><g><g><path d="m437.268 482.144h-15.115c8.244 0 14.928 6.684 14.928 14.928s-6.683 14.928-14.928 14.928h15.115c8.244 0 14.928-6.684 14.928-14.928s-6.684-14.928-14.928-14.928z" fill="#665e66"/></g><g><path d="m328.534 389.851v83.296c0 4.969 4.028 8.997 8.997 8.997h6.118v-92.293c0-27.755-22.5-50.255-50.255-50.255h-15.114c27.71 0 50.254 22.545 50.254 50.255z" fill="#665e66"/></g><g><path d="m169.664 189.426v150.17h15.115v-150.17c0-8.244-6.684-14.928-14.928-14.928h-15.115c8.245 0 14.928 6.684 14.928 14.928z" fill="#665e66"/></g></g><g><g><path d="m171.702 511.498c-61.701 0-111.898-50.197-111.898-111.898s50.197-111.898 111.898-111.898 111.898 50.197 111.898 111.898-50.197 111.898-111.898 111.898zm0-193.94c-45.238 0-82.042 36.804-82.042 82.042s36.804 82.042 82.042 82.042 82.042-36.804 82.042-82.042-36.804-82.042-82.042-82.042z" fill="#756e78"/></g></g><g><g><path d="m243.485 313.833c16.3 19.444 26.131 44.485 26.131 71.783 0 61.701-50.197 111.898-111.898 111.898-27.298 0-52.339-9.831-71.783-26.131 20.543 24.504 51.364 40.115 85.767 40.115 61.701 0 111.898-50.197 111.898-111.898 0-34.403-15.61-65.225-40.115-85.767z" fill="#665e66"/></g></g><g><path d="m384.583 259.81 13.927 12.767c8.319 7.626 13.447 18.117 14.353 29.366l.509 6.316c.283 3.513-3.591 5.82-6.545 3.898l-45.845-29.834z" fill="#ffcbbe"/></g><g><path d="m413.372 308.259-.509-6.316c-.906-11.249-6.034-21.74-14.353-29.366l-13.927-12.767-7.744 7.387 5.869 5.38c8.319 7.626 13.447 18.117 14.353 29.366l.328 4.072 9.438 6.142c2.954 1.921 6.828-.386 6.545-3.898z" fill="#fdad9d"/></g><g><g><path d="m366.869 290.965c-1.448 1.448-3.783 1.589-5.341.26-8.038-6.857-18.146-10.594-28.827-10.594h-69.416c-31.072 0-56.26-25.188-56.26-56.26v-63.312c0-12.367 10.025-22.392 22.392-22.392 12.367 0 22.392 10.025 22.392 22.392v63.312c0 6.338 5.138 11.476 11.476 11.476h69.415c22.462 0 43.657 8.238 60.136 23.284 1.672 1.526 1.716 4.151.115 5.752z" fill="#95d6a4"/></g></g><g><path d="m392.836 259.13c-16.479-15.047-37.674-23.284-60.136-23.284h-69.416c-6.338 0-11.476-5.138-11.476-11.476v-63.312c0-12.367-10.025-22.392-22.392-22.392-3.429 0-6.676.773-9.581 2.151 5.315 4.094 8.743 10.518 8.743 17.746v74.508c0 6.338 5.138 11.476 11.476 11.476h69.416c22.462 0 43.657 8.238 60.136 23.284 1.672 1.526 1.716 4.151.115 5.752l-13.663 13.663c1.907 1.181 3.739 2.503 5.469 3.979 1.558 1.329 3.893 1.188 5.341-.26l26.082-26.082c1.602-1.602 1.558-4.226-.114-5.753z" fill="#78c2a4"/></g></g></svg>
]]}   local svg_size = { w = 20, h = 20}
    local svg = renderer.load_svg(notify.svg_texture, svg_size.w, svg_size.h)
    function notify:register_callback()
        if self.callback_registered then return end
        client.set_event_callback('paint_ui', function()
            local screen = {client.screen_size()}
            local color = {15, 15, 15}
            local d = 5;
            local data = self.data;
            for f = #data, 1, -1 do
                data[f].time = data[f].time - globals.frametime()
                local alpha, h = 255, 0;
                local _data = data[f]
                if _data.time < 0 then
                    table.remove(data, f)
                else
                    local time_diff = _data.def_time - _data.time;
                    local time_diff = time_diff > 1 and 1 or time_diff;
                    if _data.time < 0.5 or time_diff < 0.5 then
                        h = (time_diff < 1 and time_diff or _data.time) / 0.5;
                        alpha = h * 255;
                        if h < 0.2 then
                            d = d + 15 * (1.0 - h / 0.2)
                        end
                    end
                    local text_data = {renderer.measure_text("dc", _data.draw)}
                    local screen_data = {
                        screen[1] / 2 - text_data[1] / 2 + 3, screen[2] - screen[2] / 100 * 17.4 + d
                    }
                    renderer.rectangle(screen_data[1] - 30, screen_data[2] - 22, text_data[1] + 60, 2, 83, 126, 242, alpha)
                    renderer.rectangle(screen_data[1] - 29, screen_data[2] - 20, text_data[1] + 58, 29, color[1], color[2],color[3], alpha <= 135 and alpha or 135)
                    renderer.line(screen_data[1] - 30, screen_data[2] - 22, screen_data[1] - 30, screen_data[2] - 20 + 30, 83, 126, 242, alpha <= 50 and alpha or 50)
                    renderer.line(screen_data[1] - 30 + text_data[1] + 60, screen_data[2] - 22, screen_data[1] - 30 + text_data[1] + 60, screen_data[2] - 20 + 30, 83, 126, 242, alpha <= 50 and alpha or 50)
                    renderer.line(screen_data[1] - 30, screen_data[2] - 20 + 30, screen_data[1] - 30 + text_data[1] + 60, screen_data[2] - 20 + 30, 83, 126, 242, alpha <= 50 and alpha or 50)
                    renderer.text(screen_data[1] + text_data[1] / 2 + 10, screen_data[2] - 5, 255, 255, 255, alpha, 'dc', nil, _data.draw)
                    renderer.texture(svg, screen_data[1] - svg_size.w/2 - 5, screen_data[2] - svg_size.h/2 - 5, svg_size.w, svg_size.h, 255, 255, 255, alpha)
                    d = d - 50
                end
            end
            self.callback_registered = true
        end)
    end
    function notify:paint(time, text)
        local timer = tonumber(time) + 1;
        for f = self.maximum_count, 2, -1 do
            self.data[f] = self.data[f - 1]
        end
        self.data[1] = {time = timer, def_time = timer, draw = text}
        self:register_callback()
    end
    return notify
end)()

local value3 = 255
local state3 = false

function clamp(v, min, max)
	return math.max(math.min(v, max), min)
end

client.set_event_callback("run_command", function()
	local increment = (1 * globals.frametime()) * 255
	
	if (value3 ~= 0 and not state3) then
		value3 =  clamp(value3 - increment, 0, 255)
	end

	if (value3 ~= 255 and state3) then
		value3 = clamp(value3 + increment, 0, 255)
	end

	if (value3 == 0) then
		state3 = true
	end

	if (value3 == 255) then
		state3 = false
	end

end)

notify:paint(5, "[mood YAW] thx use mood config: ")
notify:paint(10, "[mood YAW] QQ1642263004")
notify:paint(15, "[mood YAW] UPDATA :2021 1 16")

local function multicolor_log(...)
	local args = {...}
	local len = #args
	for i=1, len do
		local arg = args[i]
		local r, g, b = unpack(arg)

		local msg = {}

		if #arg == 3 then
			table.insert(msg, " ")
		else
			for i=4, #arg do
				table.insert(msg, arg[i])
			end
		end
		msg = table.concat(msg)

		if len > i then
			msg = msg .. "\0"
		end

		client.color_log(r, g, b, msg)
	end
end

multicolor_log({0, 255, 0, '[+] '}, {255, 255, 255, 'Connecting to the server...'})
multicolor_log({0, 255, 0, '[+] '}, {255, 255, 255, 'EYE has finished setup.'}, {82, 127, 242, ' Welcome, '})
multicolor_log({0, 255, 0, '[+] '}, {255, 255, 255, 'Succsesfully loaded:'}, {82, 127, 242, ' sv beta'})

--#region DEPENDENCIES
local edge_data = { }
local itr_history = "UNKNOWN"

local edge_count = { [1] = 7, [2] = 12, [3] = 15, [4] = 19, [5] = 23, [6] = 28, [7] = 29 }
local inv_freestanding = (function()local a=90;local b=function(c,d,e,f)local g=math.atan((d-f)/(c-e))return g*180/math.pi end;local h=function(c,d)local i,j,k,l=nil;j=math.sin(math.rad(d))l=math.cos(math.rad(d))i=math.sin(math.rad(c))k=math.cos(math.rad(c))return k*l,k*j,-i end;local m=function(n,o,p,q,r,s,t)local c,d,e=entity.get_prop(n,"m_vecOrigin")if c==nil then return-1 end;local u=function(v,w,x)local y=math.sqrt(v*v+w*w+x*x)if y==0 then return 0,0,0 end;local z=1/y;return v*z,w*z,x*z end;local A=function(B,C,D,E,F,G)return B*E+C*F+D*G end;local H,I,J=u(c-r,d-s,e-t)return A(H,I,J,o,p,q)end;local K=function(c,d)local L,M=math.rad(c),math.rad(d)local N,O,P,Q=math.sin(L),math.cos(L),math.sin(M),math.cos(M)return O*Q,O*P,-N end;local R=function(S,n,...)local T,U,V=entity.get_prop(S,"m_vecOrigin")local W,X=client.camera_angles()local Y,Z,_=entity.hitbox_position(S,0)local a0,a1,a2=entity.get_prop(n,"m_vecOrigin")local a3=nil;local a4=math.huge;if entity.is_alive(n)then local a5=b(T,U,a0,a1)for a6,a7 in pairs({...})do local a8,a9,aa=h(0,a5+a7)local ab=T+a8*55;local ac=U+a9*55;local ad=V+80;local ae,af=client.trace_bullet(n,a0,a1,a2+70,ab,ac,ad)local ag,ah=client.trace_bullet(n,a0,a1,a2+70,ab+12,ac,ad)local ai,aj=client.trace_bullet(n,a0,a1,a2+70,ab-12,ac,ad)if af<a4 then a4=af;if ah>af then a4=ah end;if aj>af then lowestdamage=aj end;if T-a0>0 then a3=a7 else a3=a7*-1 end elseif af==a4 then return 0 end end end;return a3 end;local ak=function()local S=entity.get_local_player()local al,am,an=entity.get_prop(S,"m_vecOrigin")if S==nil or al==nil then return end;local ao=entity.get_players(true)local ap,aq=client.camera_angles()local ar,as,at=K(ap,aq)local au=-1;local av=0;for aw=1,#ao do local ax=ao[aw]if entity.is_alive(ax)then local ay=m(ax,ar,as,at,al,am,an)if ay>au then au=ay;av=ax end end end;if av~=0 then local az=R(S,av,-90,90)if az~=0 then a=az end;if a<0 then return-180 elseif a>0 then return 180 end end end;return{process=ak}end)()

--#endregion

--#region DEBUG
local get_script_name = function()
    local funca, err = pcall(function() GS_THROW_ERROR() end)
    return (not funca and err:match('\\(.*):(.*):') or nil)
end

local debug_print = function(text)
    client.color_log(83, 126, 242, string.format('[%s]\0', get_script_mname()))
    client.color_log(163, 163, 163, ' ', text)
end

local debug_count = function(tab)
    local c = 0

    for _, _ in pairs(c) do
        c = c + 1
    end
    
    return c
end

--#endregion

--#region SCRIPT
local script = {
    debug = false,
    version = 'v1.0.0 beta',

    menu = { 'aa', 'Anti-aimbot angles' },
    menu_fakelag = { 'aa', 'Fake lag' },
    menu_indicators = { 'aa', 'Other' },

    yaw_base = { 'Local view', 'At targets' },
    
    conditions = { 'Default', 'Running', 'Slow motion', 'Air', 'Manual' },
    jitter_type = { 'Off', 'Offset', 'Center', 'Random', 'Body yaw' },
    fr_type = { 'Off', 'Hide real', 'Hide fake' },

    fakelag_triggers = { 'On jump', 'On high speed', 'On duck', 'On stand', 'While moving', --[['On enemy visible', 'While enemy visible']] },
    brute_options = { 'On hit', 'On miss', 'On shot' },
    indicator_options = { 'Manual indicator', 'Desync indicator', 'Other indicators', 'Manual indicator(2)','Manual indicator(3)','Manual indicator(debug)'},
    indicator_others = { 'Minimum damage', 'Double tap', 'On shot', 'Freestanding', 'Force safe', 'Force baim', 'EDGE yaw' }
}

function script:ui(func, name, ...)
    if func == nil then
        return
    end

    local end_name = name[2] or ''

    if name[1] ~= nil then
        end_name = end_name ~= '' and string.format('%s ', end_name) or end_name
        end_name = string.format('%s\n %s', end_name, name[1])
    end

    if name[1] == 'ss_fakelag' or name[1] == 'ss_fakelag_custom' or name[1] == 'ss_fakelag_triggers' then
        return func(self.menu_fakelag[1], self.menu_fakelag[2], end_name, ...)
    end

    if name[1] == 'ss_indicators' or name[1] == 'ss_indicators_options' or name[1] == 'ss_indicators_clr' or name[1] == 'ss_indicators_others' then
        return func(self.menu_indicators[1], self.menu_indicators[2], end_name, ...)
    end

    return func(self.menu[1], self.menu[2], end_name, ...)
end

--#endregion

--#region CONTROLS
local enabled               = script:ui(ui.new_checkbox, { 'ss_enabled', 'MOOD YAW anti-aim' })
local global_color          = script:ui(ui.new_color_picker, { 'ss_globalclr', 'global_clr_picker' }, 255, 255, 255, 255)

local edgeyaw_key           = script:ui(ui.new_hotkey, { 'ss_edgeyaw_key', 'Edge yaw hotkey' })

local manual_enabled        = script:ui(ui.new_checkbox, { 'ss_manual', 'Manual anti-aims' })
local manual_color          = script:ui(ui.new_color_picker, { 'ss_manualclr', 'manual_clr_picker' }, 255, 255, 255, 255)
local manual_left_hotkey    = script:ui(ui.new_hotkey, { 'ss_lefthk', 'Manual left' })
local manual_right_hotkey   = script:ui(ui.new_hotkey, { 'ss_righthk', 'Manual right' })
local manual_restore_hotkey = script:ui(ui.new_hotkey, { 'ss_restorehk', 'Manual restore' })
local manual_dir            = script:ui(ui.new_slider, { 'ss_manual_state', 'manual state' }, 0, 3, 0)

local brute_enabled         = script:ui(ui.new_checkbox, { 'ss_brute', 'Anti-bruteforce' })
local brute_conditions      = script:ui(ui.new_multiselect, { 'ss_brute_conditions', 'Anti-bruteforce conditions' }, script.brute_options )
local brute_radius          = script:ui(ui.new_slider, { 'ss_brute_radius', 'Radius' }, 0, 125, 125)

local conditions_label      = script:ui(ui.new_label, { 'ss_conditions_label', 'Current condition: unknown' })
local conditions_current    = script:ui(ui.new_combobox, { 'ss_conditions_current', nil }, script.conditions )

local fakelag_enabled       = script:ui(ui.new_checkbox, { 'ss_fakelag', '808hp fake lag' })
local fakelag_custom        = script:ui(ui.new_checkbox, { 'ss_fakelag_custom', 'Customize triggers' })
local fakelag_triggers      = script:ui(ui.new_multiselect, {'ss_fakelag_triggers', nil }, script.fakelag_triggers )

local indicators_enabled    = script:ui(ui.new_checkbox, { 'ss_indicators', '808hp indicators' })
local indicators_color      = script:ui(ui.new_color_picker, { 'ss_indicators_clr', 'indicators_clr_picker' }, 255, 255, 255, 255)
local indicators_options    = script:ui(ui.new_multiselect, { 'ss_indicators_options', 'Indicator options' }, script.indicator_options )
local indicators_other      = script:ui(ui.new_multiselect, { 'ss_indicators_others', 'Other indicators' }, script.indicator_others )

--#endregion

--#region MENU_DATA
local menu_data = {
    ['Default'] = {
        base = script:ui(ui.new_combobox, { 'ss_default_base', 'Yaw base' }, script.yaw_base),

        yaw = script:ui(ui.new_slider, { 'ss_default_yaw', 'Yaw' }, -180, 180, 0, true, '°'),

        limit = script:ui(ui.new_slider, { 'ss_default_limit', 'Fake yaw limit' }, 0, 60, 60, true, '°'),

        yaw_jitter = script:ui(ui.new_combobox, { 'ss_default_jitter', 'Yaw jitter' }, script.jitter_type),
        yaw_jitter_val = script:ui(ui.new_slider, { 'ss_default_jitter_value', nil }, -180, 180, 0, true, '°'),
        --yaw_jitter_dsync = script:ui(ui.new_checkbox, { 'ss_default_jitter_desync', 'Disable jitter synchronization' }),

        freestanding = script:ui(ui.new_combobox, { 'ss_default_fs', 'Freestanding body direction' }, script.fr_type)
    },
    ['Running'] = {
        base = script:ui(ui.new_combobox, { 'ss_running_base', 'Yaw base' }, script.yaw_base),

        yaw = script:ui(ui.new_slider, { 'ss_running_yaw', 'Yaw' }, -180, 180, 0, true, '°'),

        limit = script:ui(ui.new_slider, { 'ss_running_limit', 'Fake yaw limit' }, 0, 60, 60, true, '°'),

        yaw_jitter = script:ui(ui.new_combobox, { 'ss_running_jitter', 'Yaw jitter' }, script.jitter_type),
        yaw_jitter_val = script:ui(ui.new_slider, { 'ss_running_jitter_value', nil }, -180, 180, 0, true, '°'),
        --yaw_jitter_dsync = script:ui(ui.new_checkbox, { 'ss_running_jitter_desync', 'Disable jitter synchronization' }),

        freestanding = script:ui(ui.new_combobox, { 'ss_running_fs', 'Freestanding body direction' }, script.fr_type)
    },
    ['Slow motion'] = {
        base = script:ui(ui.new_combobox, { 'ss_slow_base', 'Yaw base' }, script.yaw_base),

        yaw = script:ui(ui.new_slider, { 'ss_slow_yaw', 'Yaw' }, -180, 180, 0, true, '°'),

        limit = script:ui(ui.new_slider, { 'ss_slow_limit', 'Fake yaw limit' }, 0, 60, 60, true, '°'),

        yaw_jitter = script:ui(ui.new_combobox, { 'ss_slow_jitter', 'Yaw jitter' }, script.jitter_type),
        yaw_jitter_val = script:ui(ui.new_slider, { 'ss_slow_jitter_value', nil }, -180, 180, 0, true, '°'),
        --yaw_jitter_dsync = script:ui(ui.new_checkbox, { 'ss_slow_jitter_desync', 'Disable jitter synchronization' }),

        freestanding = script:ui(ui.new_combobox, { 'ss_slow_fs', 'Freestanding body direction' }, script.fr_type)
    },
    ['Air'] = {
        base = script:ui(ui.new_combobox, { 'ss_air_base', 'Yaw base' }, script.yaw_base),

        yaw = script:ui(ui.new_slider, { 'ss_air_yaw', 'Yaw' }, -180, 180, 0, true, '°'),

        limit = script:ui(ui.new_slider, { 'ss_air_limit', 'Fake yaw limit' }, 0, 60, 60, true, '°'),

        yaw_jitter = script:ui(ui.new_combobox, { 'ss_air_jitter', 'Yaw jitter' }, script.jitter_type),
        yaw_jitter_val = script:ui(ui.new_slider, { 'ss_air_jitter_value', nil }, -180, 180, 0, true, '°'),
        --yaw_jitter_dsync = script:ui(ui.new_checkbox, { 'ss_air_jitter_desync', 'Disable jitter synchronization' }),

        freestanding = script:ui(ui.new_combobox, { 'ss_air_fs', 'Freestanding body direction' }, script.fr_type)
    },
    ['Manual'] = {
        base = script:ui(ui.new_combobox, { 'ss_manual_base', 'Yaw base' }, script.yaw_base),

        yaw = script:ui(ui.new_slider, { 'ss_manual_yaw', 'Yaw' }, -180, 180, 0, true, '°'),

        limit = script:ui(ui.new_slider, { 'ss_manual_limit', 'Fake yaw limit' }, 0, 60, 60, true, '°'),

        yaw_jitter = script:ui(ui.new_combobox, { 'ss_manual_jitter', 'Yaw jitter' }, script.jitter_type),
        yaw_jitter_val = script:ui(ui.new_slider, { 'ss_manual_jitter_value', nil }, -180, 180, 0, true, '°'),
        --yaw_jitter_dsync = script:ui(ui.new_checkbox, { 'ss_manual_jitter_desync', 'Disable jitter synchronization' }),

        ignore_sideways = script:ui(ui.new_checkbox, { 'ss_manual_ignore_sideways', 'Ignore sideways' }),

        freestanding = script:ui(ui.new_combobox, { 'ss_manual_fs', 'Freestanding body direction' }, script.fr_type)
    },
}

--#endregion

--#region REFERENCE
local ref           = ui.reference('aa', 'Anti-aimbot angles', 'Enabled')
local pitch         = ui.reference('aa', 'Anti-aimbot angles', 'Pitch')
local yawbase       = ui.reference('aa', 'Anti-aimbot angles', 'Yaw base')
local yaw           = { ui.reference('aa', 'Anti-aimbot angles', 'Yaw') }
local yawjitter     = { ui.reference('aa', 'Anti-aimbot angles', 'Yaw jitter') }
local bodyyaw       = { ui.reference('aa', 'Anti-aimbot angles', 'Body yaw') }
local fsbodyyaw     = ui.reference('aa', 'Anti-aimbot angles', 'Freestanding body yaw')
local lbytarget     = ui.reference('aa', 'Anti-aimbot angles', 'Lower body yaw target')
local limit         = ui.reference('aa', 'Anti-aimbot angles', 'Fake yaw limit')
local edgeyaw       = ui.reference('aa', 'Anti-aimbot angles', 'Edge yaw')
local freestanding  = { ui.reference('aa', 'Anti-aimbot angles', 'Freestanding') }
local slowmo        = { ui.reference('aa', 'Other', 'Slow motion') }
local slowmo_type   = ui.reference('aa', 'Other', 'Slow motion type')
local legmovement   = ui.reference('aa', 'Other', 'Leg movement')
local onshot        = { ui.reference('aa', 'Other', 'On shot anti-aim') }
local doubletap, dt_hk     = { ui.reference('rage', 'Other', 'Double tap') }
local baim          = ui.reference('rage', 'Other', 'Force body aim')
local safe          = ui.reference('rage', 'Aimbot', 'Force safe point')
local damage        = ui.reference('rage', 'Aimbot', 'Minimum damage')
local fakelag       = ui.reference('aa', 'Fake lag', 'Enabled')
local sv_maxusrcmds = ui.reference('misc', 'Settings', 'sv_maxusrcmdprocessticks')


--#endregion

--#region VARS
local bind_system = {
    left = false,
    right = false,
    restore = false
}

local alpha = 255
local add = 1
local reduce = false

local should_swap = false
local it = 0
local angles = { -141, 141 }

--#endregion

--#region HELPERS
local multi_exec = function(func, list)
    if func == nil then
        return
    end

    for ref, val in pairs(list) do
        func(ref, val)
    end
end

local contains = function(tab, val)
    for i=1, #tab do
        if tab[i] == val then
            return true
        end
    end

    return false
end

local fix_multiselect = function(multiselect, value)
    local number = ui.get(multiselect)
    if #number == 0 then
        ui.set(multiselect, value)
    end
end

local get_flags = function(cmd)
    local state = 'Default'
    local me = entity.get_local_player()

    local flags = entity.get_prop(me, 'm_fFlags')
    local x, y, z = entity.get_prop(me, 'm_vecVelocity')
    local velocity = math.floor(math.min(10000, math.sqrt(x^2 + y^2) + 0.5))

    if bit.band(flags, 1) ~= 1 or (cmd and cmd.in_jump == 1) then state = "Air" else
        if velocity > 1 or (cmd.sidemove ~= 0 or cmd.forwardmove ~= 0) then
            if ui.get(slowmo[1]) and ui.get(slowmo[2]) then 
                state = 'Slow motion'
            else
                state = 'Running'
            end
        else
            state = 'Default'
        end
    end

    return {
        velocity = velocity,
        state = state
    }
end

local get_closeset_point = function(a, b, p)
    local a_to_p = { p[1] - a[1], p[2] - a[2] }
    local a_to_b = { b[1] - a[1], b[2] - a[2] }

    local atb2 = a_to_b[1]^2 + a_to_b[2]^2

    local atp_dot_atb = a_to_p[1]*a_to_b[1] + a_to_p[2]*a_to_b[2]
    local t = atp_dot_atb / atb2
    
    return { a[1] + a_to_b[1]*t, a[2] + a_to_b[2]*t }
end

--#endregion

--#region MANUAL
function bind_system:update()
    ui.set(manual_left_hotkey, 'On hotkey')
    ui.set(manual_right_hotkey, 'On hotkey')
    ui.set(manual_restore_hotkey, 'On hotkey')

    ui.set(edgeyaw_key, 'On toggle')

    local m_state = ui.get(manual_dir)

    local left_s, right_s, restore_s = ui.get(manual_left_hotkey), ui.get(manual_right_hotkey), ui.get(manual_restore_hotkey)

    if left_s == self.left and right_s == self.right and restore_s == self.restore then
        return
    end

    self.left, self.right, self.restore = left_s, right_s, restore_s

    if (left_s and m_state == 1) or (right_s and m_state == 2) or (restore_s and m_state == 3) then
        ui.set(manual_dir, 0)
        return
    end

    if left_s and m_state ~= 1 then
        ui.set(manual_dir, 1)
    end

    if right_s and m_state ~= 2 then
        ui.set(manual_dir, 2)
    end

    if restore_s and m_state ~= 3 then
        ui.set(manual_dir, 0)
    end
end

--#endregion

--#region VISIBILITY
local bind_callback = function(list, callback, elem)
    for k in pairs(list) do
        if type(list[k]) == 'table' and list[k][elem] ~= nil then
            ui.set_callback(list[k][elem], callback)
        end
    end
end

local menu_callback = function(e, menu_call)
    local setup_conditions = function(list, current_condition, vis)
        for k in pairs(list) do
            local mode = list[k]
            local active = k == current_condition

            if type(mode) == 'table' then
                for j in pairs(mode) do
                    local set_element = true
                
                    local jit_mode = ui.get(mode.yaw_jitter)
                    local is_body_jitter = jit_mode == script.jitter_type[5]

                    if jit_mode == 'Off' and (j == 'yaw_jitter_val' or j == 'yaw_jitter_dsync') then 
                        set_element = false
                    end

                    if is_body_jitter and j == 'opposite' then
                        set_element = false
                    end

                    ui.set_visible(mode[j], active and vis and set_element)
                end
            end
        end
    end

    local script_state      = not ui.get(enabled)
    local manual_state      = ui.get(manual_enabled)
    local fakelag_state     = ui.get(fakelag_enabled)
    local brute_state       = ui.get(brute_enabled)
    local indicator_state   = ui.get(indicators_enabled)

    if e == nil then
        script_state = true
    end

    if menu_call == nil then
        setup_conditions(menu_data, ui.get(conditions_current), not script_state)
    end

    multi_exec(ui.set_visible, {
        [edgeyaw_key]               = not script_state,

        [manual_enabled]            = not script_state,
        [manual_color]              = not script_state,
        [manual_left_hotkey]        = not script_state and manual_state,
        [manual_right_hotkey]       = not script_state and manual_state,
        [manual_restore_hotkey]     = not script_state and manual_state,

        [fakelag_enabled]           = not script_state,
        [fakelag_custom]            = not script_state and fakelag_state,
        [fakelag_triggers]          = not script_state and fakelag_state and ui.get(fakelag_custom),

        [conditions_label]          = not script_state,
        [conditions_current]        = not script_state,

        [brute_enabled]             = not script_state,
        [brute_conditions]          = not script_state and brute_state,
        [brute_radius]              = not script_state and brute_state,
    
        [indicators_enabled]        = not script_state,
        [indicators_color]          = not script_state,
        [indicators_options]        = not script_state and indicator_state,
        [indicators_other]          = not script_state and indicator_state and contains(ui.get(indicators_options), 'Other indicators'),
    
        [manual_dir]                = false,
    })

    if script.debug then
        script_state = true
    end

    local byaw = ui.get(yaw[1])
    local bnum = ui.get(bodyyaw[1])

    multi_exec(ui.set_visible, {
        [ref]           = script_state,
        [yawbase]       = script_state,
        
        [yaw[1]]        = script_state,
        [yaw[2]]        = script_state and byaw ~= 'Off',

        [yawjitter[1]]  = script_state and byaw ~= 'Off', 
        [yawjitter[2]]  = script_state and byaw ~= 'Off' and ui.get(yawjitter[1]) ~= 'Off',

        [bodyyaw[1]]    = script_state,
        [bodyyaw[2]]    = script_state and byaw ~= 'Off' and bnum ~= 'Opposite',

        [fsbodyyaw]     = script_state,
        [lbytarget]     = script_state,
        [limit]         = script_state and byaw ~= 'Off',
        [edgeyaw]       = script_state
    })
end

--#endregion

--#region EVENTS
local on_setup_command = function(cmd)
    if not ui.get(enabled) then
        return
    end

    itr_history = 'UNKNOWN'

    local fr_active = ui.get(freestanding[1]) and ui.get(freestanding[2])

    if ui.get(edgeyaw_key) then
        ui.set(edgeyaw, true)

        return
    else
        ui.set(edgeyaw, false)
    end

    local data = get_flags(cmd)
    local direction = ui.get(manual_dir)
    local state = (direction ~= 0 and not fr_active) and 'Manual' or data.state

    local stack = menu_data[state]

    if stack == nil then
        return
    end

    local manual_yaw = {
        [0] = direction ~= 0 and '0' or ui.get(stack.yaw),
        [1] = -90, [2] = 90
    }

    local jit_mode = ui.get(stack.yaw_jitter)
    local jit_val = ui.get(stack.yaw_jitter_val)
    local is_body_jitter = jit_mode == script.jitter_type[5]

    if state == 'Manual' and ui.get(stack.ignore_sideways) then
        manual_yaw[1] = -90
        manual_yaw[2] = 90
    end

    local body_yaw = {
       [false] = 'Static',
       [true] = 'Opposite'
    }

    local end_data = {
       yaw_num = fr_active and 0 or manual_yaw[direction],
       body_num = is_body_jitter and jit_val or (should_swap and 141 or -141)
    }

    if ui.get(stack.freestanding) == script.fr_type[3] then
        manual_yaw[0] = 0

        local angle = inv_freestanding:process()

        if angle ~= nil then
            end_data = {
                yaw_num = manual_yaw[direction],
                body_num = angle
            }
        end
    end

    local fake_limit = ui.get(stack.limit)

    local is_exploit = ui.get(doubletap[1]) and ui.get(doubletap[2]) or ui.get(onshot[1]) and ui.get(onshot[2])
    local lbyt = is_exploit and 'Eye yaw' or 'Opposite'
    
    multi_exec(ui.set, {
        [ref] = true,

        [yaw[1]] = '180',
        [bodyyaw[1]] =  is_body_jitter and 'Jitter' or body_yaw[false],

        [yaw[2]] = end_data.yaw_num,
        [bodyyaw[2]] = end_data.body_num,

        [yawjitter[1]] = not is_body_jitter and ui.get(stack.yaw_jitter) or 'Off',
        [yawjitter[2]] = jit_val,

        [yawbase] = state == 'Manual' and 'Local view' or ui.get(stack.base),

        [lbytarget] = lbyt,
        [limit] = fake_limit,

        [fsbodyyaw] = ui.get(stack.freestanding) == script.fr_type[2],
        [edgeyaw] = false
    })

    ui.set(conditions_label, 'Current conditions ' ..  state)
    fix_multiselect(fakelag_triggers, 'On jump')

    if ui.get(fakelag_enabled) then
        ui.set(fakelag, true)

        if not ui.get(fakelag_custom) then
            cmd.allow_send_packet = false
        else
            if contains(ui.get(fakelag_triggers), 'On jump') and state == 'Air' then
                cmd.allow_send_packet = false
            end

            if contains(ui.get(fakelag_triggers), 'On high speed') and data.velocity > 180 then
                cmd.allow_send_packet = false
            end

            if contains(ui.get(fakelag_triggers), 'On duck') then
                if entity.get_prop(entity.get_local_player(), 'm_flDuckAmount') >= 0.7 then
                    cmd.allow_send_packet = false
                end
            end

            if contains(ui.get(fakelag_triggers), 'On stand') and state == 'Default' then
                cmd.allow_send_packet = false
            end

            if contains(ui.get(fakelag_triggers), 'While moving') then
                if state == 'Running' or state == 'Slow motion' then
                    cmd.allow_send_packet = false
                end
            end
        end
    else
        cmd.allow_send_packet = true
    end
end

local on_paint = function()
    bind_system:update()
    menu_callback(true, true)

    local me = entity.get_local_player()

    if not entity.is_alive(me) or not ui.get(enabled) then
        return
    end

    local realtime = globals.realtime() % 3
    local w, h = client.screen_size()

    local fr_active = ui.get(freestanding[1]) and ui.get(freestanding[2])
    local os_active = ui.get(onshot[1]) and ui.get(onshot[2])

    local indicators = ui.get(indicators_options)

    if ui.get(manual_enabled) and contains(indicators, 'Manual indicator') then
        local r, g, b, a = ui.get(manual_color)
        
        local _alpha = not os_active and math.floor(math.sin(realtime * 4) * ((a-50)/2-1) + (a-50)/2) or (a-50)
        local static_alpha = math.floor(math.sin(realtime * 2) * (a/2-1) + a/2)

        local dir = ui.get(manual_dir)

        local distance = 42

        if dir == 1 or fr_active then renderer.text(w/2 - distance, h / 2 - 3, r, g, b, 50 + _alpha, "+c", 0, "⯇") end
        if dir == 2 or fr_active then renderer.text(w/2 + distance, h / 2 - 3, r, g, b, 50 + _alpha, "+c", 0, "⯈") end

        if dir ~= 1 and not fr_active then renderer.text(w/2 - distance, h / 2 - 3, 50, 50, 50, 150, "c+", 0, "⯇") end
		if dir ~= 2 and not fr_active then renderer.text(w/2 + distance, h / 2 - 3, 50, 50, 50, 150, "c+", 0, "⯈") end
    
        if dir == 1 or dir == 2 or fr_active then renderer.text(w/2, h / 2 + distance, 50, 50, 50, 150, "+c", 0, "⯆") 
           -- y_offset = y_offset + 12    
        end
        if dir == 0 then renderer.text(w/2, h / 2 + distance, r, g, b, 50 + _alpha, "+c", 0, "⯆") end
    end

    if contains(indicators, 'Desync indicator') then
        local r, g, b, a = ui.get(global_color)

        local _alpha = math.floor(math.sin(realtime * 4) * ((a-50)/2-1) + (a-50)/2) or (a-50)
        local static_alpha = math.floor(math.sin(realtime * 2) * (a/2-1) + a/2)

        local desyncside = ''

        if ui.get(bodyyaw[2]) > 0 then
            desyncside = 'RIGHT'
        elseif ui.get(bodyyaw[2]) < 0 then
            desyncside = 'LEFT'
        end

        renderer.triangle(
			w / 2 - 40, h/ 2 + 24,w / 2 - 24, h /2 + 40,w / 2 - 38, h/ 2 + 38,
			desyncside == 'LEFT' and r or 50,
			desyncside == 'LEFT' and g or 50,
			desyncside == 'LEFT' and b or 50,
			desyncside == 'LEFT' and 50 + _alpha or 150)

		renderer.triangle(w / 2 + 40, h/ 2 + 24,w / 2 + 24, h /2 + 40,w / 2 + 38, h/ 2 + 38, 
			side == 'RIGHT' and r or 50,
			desyncside == 'RIGHT' and g or 50,
			desyncside == 'RIGHT' and b or 50,
			desyncside == 'RIGHT' and 50 + _alpha or 150)
    end

    if contains(indicators, 'Other indicators') then
        local y_offset = 32
        local r, g, b, a = 50, 50, 50, 150
        
        r, g, b, a = ui.get(indicators_color)
        if contains(ui.get(indicators_other), 'Minimum damage') then renderer.text(w/2 + 1, h/2 + y_offset, 50, 50, 50, 150, 'cb', 0, ui.get(damage)) end
        y_offset = y_offset + 12
        --if ui.get(doubletap[2]) then
        --if ui.get(doubletap[1]) and ui.get(doubletap[2]) then   
          --  r, g, b, a = ui.get(indicators_color)
        --end

        if ui.get(doubletap[1]) and ui.get(doubletap[2]) then
            r, g, b, a = ui.get(indicators_color)
        else 
            r, g, b, a = 50, 50, 50, 150
        end


  
            if ui.get(manual_enabled) and contains(indicators, 'Manual indicator(2)') then
                local r, g, b, a = ui.get(manual_color)
                
                local _alpha = not os_active and math.floor(math.sin(realtime * 4) * ((a-50)/2-1) + (a-50)/2) or (a-50)
                local static_alpha = math.floor(math.sin(realtime * 2) * (a/2-1) + a/2)
        
                local dir = ui.get(manual_dir)
        
                local distance = 42
        
                if dir == 1 or fr_active then renderer.text(w/2 - distance, h / 2 - 3, r, g, b, 50 + _alpha, "+c", 0, "<  ") end
                if dir == 2 or fr_active then renderer.text(w/2 + distance, h / 2 - 3, r, g, b, 50 + _alpha, "+c", 0, "  >") end
        
                if dir ~= 1 and not fr_active then renderer.text(w/2 - distance, h / 2 - 3, 50, 50, 50, 150, "c+", 0, "<  ") end
                if dir ~= 2 and not fr_active then renderer.text(w/2 + distance, h / 2 - 3, 50, 50, 50, 150, "c+", 0, "  >") end
            
                if dir == 1 or dir == 2 or fr_active then renderer.text(w/2, h / 2 + distance, 50, 50, 50, 150, "+c", 0, "") 
                   -- y_offset = y_offset + 12    
                end
                if dir == 0 then renderer.text(w/2, h / 2 + distance, r, g, b, 50 + _alpha, "+c", 0, "") end
            end

              
            if ui.get(manual_enabled) and contains(indicators, 'Manual indicator(3)') then
                local r, g, b, a = ui.get(manual_color)
                
                local _alpha = not os_active and math.floor(math.sin(realtime * 4) * ((a-50)/2-1) + (a-50)/2) or (a-50)
                local static_alpha = math.floor(math.sin(realtime * 2) * (a/2-1) + a/2)
        
                local dir = ui.get(manual_dir)
        
                local distance = 42
        
                if dir == 1 or fr_active then renderer.text(w/2 - distance, h / 2 - 3, r, g, b, 50 + _alpha, "+c", 0, "⮘") end
                if dir == 2 or fr_active then renderer.text(w/2 + distance, h / 2 - 3, r, g, b, 50 + _alpha, "+c", 0, "⮚") end
        
                if dir ~= 1 and not fr_active then renderer.text(w/2 - distance, h / 2 - 3, 50, 50, 50, 150, "c+", 0, "⮘") end
                if dir ~= 2 and not fr_active then renderer.text(w/2 + distance, h / 2 - 3, 50, 50, 50, 150, "c+", 0, "⮚") end
            
                if dir == 1 or dir == 2 or fr_active then renderer.text(w/2, h / 2 + distance, 50, 50, 50, 150, "+c", 0, "⮛") 
                   -- y_offset = y_offset + 12    
                end
                if dir == 0 then renderer.text(w/2, h / 2 + distance, r, g, b, 50 + _alpha, "+c", 0, "⮛") end
            end

            if ui.get(manual_enabled) and contains(indicators, 'Manual indicator(debug)') then
                local r, g, b, a = ui.get(manual_color)
                
                local _alpha = not os_active and math.floor(math.sin(realtime * 4) * ((a-50)/2-1) + (a-50)/2) or (a-50)
                local static_alpha = math.floor(math.sin(realtime * 2) * (a/2-1) + a/2)
        
                local dir = ui.get(manual_dir)
        
                local distance = 42
        
                if dir == 1 or fr_active then renderer.text(w/2 - distance, h / 2 - 3, r, g, b, 50 + _alpha, "+c", 0, "⮜") end
                if dir == 2 or fr_active then renderer.text(w/2 + distance, h / 2 - 3, r, g, b, 50 + _alpha, "+c", 0, "⮞") end
        
                if dir ~= 1 and not fr_active then renderer.text(w/2 - distance, h / 2 - 3, 50, 50, 50, 150, "c+", 0, "⮜") end
                if dir ~= 2 and not fr_active then renderer.text(w/2 + distance, h / 2 - 3, 50, 50, 50, 150, "c+", 0, "⮞") end
            
                if dir == 1 or dir == 2 or fr_active then renderer.text(w/2, h / 2 + distance, 50, 50, 50, 150, "+c", 0, "⮟") 
                   -- y_offset = y_offset + 12    
                end
                if dir == 0 then renderer.text(w/2, h / 2 + distance, r, g, b, 50 + _alpha, "+c", 0, "⮟") end
            end

        if contains(ui.get(indicators_other), 'Double tap') then renderer.text(w/2, h/2 + y_offset, r, g, b, a, 'cb', 0, 'DOUBLE TAP')
            y_offset = y_offset + 12 
        end

        r, g, b, a = 50, 50, 50, 150
        if ui.get(onshot[1]) and ui.get(onshot[2]) then
            r, g, b, a = ui.get(indicators_color)
        end
        --y_offset = y_offset + 12
        if contains(ui.get(indicators_other), 'On shot') then renderer.text(w/2, h/2 + y_offset, r, g, b, a, 'cb', 0, 'ON-SHOT')
            y_offset = y_offset + 12 
        end

        r, g, b, a = 50, 50, 50, 150
        if ui.get(freestanding[1]) and ui.get(freestanding[2]) then
            r, g, b, a = ui.get(indicators_color)
        end
        --y_offset = y_offset + 12
        if contains(ui.get(indicators_other), 'Freestanding') then renderer.text(w/2, h/2 + y_offset, r, g, b, a, 'cb', 0, 'FREESTANDING')
            y_offset = y_offset + 12 
        end
        r, g, b, a = 50, 50, 50, 150
        if ui.get(safe) then
            r, g, b, a = ui.get(indicators_color)
        end
        --y_offset = y_offset + 12
        if contains(ui.get(indicators_other), 'Force safe') then renderer.text(w/2, h/2 + y_offset, r, g, b, a, 'cb', 0, 'FORCE SAFE POINT')
            y_offset = y_offset + 12 
        end
        r, g, b, a = 50, 50, 50, 150
        if ui.get(baim) then
            r, g, b, a = ui.get(indicators_color)
        end
        --y_offset = y_offset + 12
        if contains(ui.get(indicators_other), 'Force baim') then renderer.text(w/2, h/2 + y_offset, r, g, b, a, 'cb', 0, 'FORCE B0DY AIM')
            y_offset = y_offset + 12
        end
        r, g, b, a = 50, 50, 50, 150
        if ui.get(edgeyaw) then
            r, g, b, a = ui.get(indicators_color)
        end
        --y_offset = y_offset + 12
        if contains(ui.get(indicators_other), 'Edge yaw') then renderer.text(w/2, h/2 + y_offset, r, g, b, a, 'cb', 0, 'EDGE YAW')
            y_offset = y_offset + 12 
        end

    end
end

local on_bullet_impact = function(c)
    local state = ui.get(brute_enabled)

    if state and entity.is_alive(entity.get_local_player()) then
        local ent = client.userid_to_entindex(c.userid)

        if not entity.is_dormant(ent) and entity.is_enemy(ent) and contains(ui.get(brute_conditions), 'On miss') then
            local ent_shoot = { entity.get_prop(ent, "m_vecOrigin") }

            ent_shoot[3] = ent_shoot[3] + entity.get_prop(ent, "m_vecViewOffset[2]")

            local player_head = { entity.hitbox_position(entity.get_local_player(), 0) }
            local closest = get_closeset_point(ent_shoot, { c.x, c.y, c.z }, player_head)
            local delta = { player_head[1]-closest[1], player_head[2]-closest[2] }
            local delta_2d = math.sqrt(delta[1]^2+delta[2]^2)
        
            if math.abs(delta_2d) < ui.get(brute_radius) then
                it = it + 1

                if should_swap == true then
                    should_swap = false
                else
                    should_swap = true
                end
            end
        end
    end
end

local on_player_hurt = function(e)
    local victim_userid, attacker_userid = e.userid, e.attacker
	local victim_entindex = client.userid_to_entindex(victim_userid)
    local attacker_entindex = client.userid_to_entindex(attacker_userid)
    
    local state = ui.get(brute_enabled)

    if state and entity.is_enemy(attacker_entindex) and victim_entindex == entity.get_local_player() and contains(ui.get(brute_conditions), 'On hit') then
        if should_swap == true then
            should_swap = false
        else
            should_swap = true
        end
    end
end

local on_aim_fire = function(e)
    local state = ui.get(brute_enabled)

    if state and contains(ui.get(brute_conditions), 'On shot') then
        if should_swap == true then
            should_swap = false
        else
            should_swap = true
        end
    end
end

--#endregion

--INITIALIZATION
local script_toggled = function()
    local script_state = ui.get(enabled)

    menu_callback(true, true)
    ui.set_visible(sv_maxusrcmds, true)

    fix_multiselect(fakelag_triggers, 'On jump')

    local update_callback = script_state and client.set_event_callback or client.unset_event_callback
    update_callback('paint', on_paint)
    update_callback('setup_command', on_setup_command)
    update_callback('shutdown', menu_callback)
    update_callback('bullet_impact', on_bullet_impact)
    update_callback('player_hurt', on_player_hurt)
    update_callback('aim_fire', on_aim_fire)
end

menu_callback(enabled)
bind_callback(menu_data, menu_callback, 'yaw_jitter')
bind_callback(menu_data, menu_callback, 'freestanding')

ui.set_callback(enabled, menu_callback)
ui.set_callback(enabled, script_toggled)
ui.set_callback(manual_enabled, menu_callback)
ui.set_callback(conditions_current, menu_callback)
ui.set_callback(fakelag_enabled, menu_callback)
ui.set_callback(fakelag_custom, menu_callback)
ui.set_callback(brute_enabled, menu_callback)
ui.set_callback(indicators_enabled, menu_callback)
ui.set_callback(indicators_other, menu_callback)


legit_e_key = ui.new_checkbox("AA", "Anti-aimbot angles", "Legit anti-aim (on E key)")
freestanding_body_yaw = ui.reference("AA", "Anti-aimbot angles", "Freestanding body yaw")

client.set_event_callback("setup_command",function(e)
    local weaponn = entity.get_player_weapon()
    if ui.get(legit_e_key) then
        if weaponn ~= nil and entity.get_classname(weaponn) == "CC4" then
            if e.in_attack == 1 then
                e.in_attack = 0 
                e.in_use = 1
            end
        else
            if e.chokedcommands == 0 then
                e.in_use = 0
            end
        end
        ui.set(freestanding_body_yaw, true)
end
end)

slidewalk = ui.reference("AA", "other", "leg movement")
enable = ui.new_checkbox("AA", "other", "LEG FUYCJKER UFF $$$$")

client.set_event_callback("net_update_end", function()
	if ui.get(enable) then
		entity.set_prop(entity.get_local_player(), "m_flPoseParameter", 1, 0)
	end
end)

client.set_event_callback("run_command", function(ctx)
    if ui.get(enable) then
	p = client.random_int(1, 3)
	if p == 1 then
		ui.set(slidewalk, "Off")
	elseif p == 2 then
       ui.set(slidewalk, "Always slide")
    elseif p == 3 then
		ui.set(slidewalk, "Off")
    end
    ui.set_visible(slidewalk, false)
else
    ui.set_visible(slidewalk, true)
end
end)


local width, height = client.screen_size()
local center_width = width/2
local center_height = height/2




--- Client First Log
client.color_log(0, 255, 255, " ----- WELCOME ADMIN ! -----")
client.color_log(0, 150, 255, " ----- SKEET.CC ANTI AIM ALREADY ACTIVE! -----")
client.color_log(150, 0, 200, " ----- ENJOY GAMESENSE!-----")
client.color_log(225, 0, 225, " ----- THANKS FOR USE -----")
client.color_log(255, 150, 175, " ----- [EYE Edition] SKEET.CC AA + Loader Over -----")
client.color_log(175, 255, 0, " ----- [EYE Edition] SKEET.CC AA + Loader Over -----")
client.color_log(255, 255, 255, " ----- [EYE Edition] SKEET.CC AA + Loader Over -----")
client.color_log(0, 255, 255, " ----- [EYE Edition] SKEET.CC AA + Loader Over -----")
client.color_log(0, 255, 255, " ----- [EYE Edition] SKEET.CC AA + Loader Over -----")
client.color_log(0, 255, 255, " ----- [EYE Edition] SKEET.CC AA + Loader Over -----")

client.set_event_callback("paint",function()
	local _x, _y = client.screen_size()
	local y = _y / 2
	local x = _x / 2
	renderer.text(x, y + 680, 176, 196, 222, 255, "", 0, "DD")
	renderer.text(x, y + 690, 176, 196, 222, 255, "", 0, "Welcome,admin")
    renderer.text(x, y + 700, 176, 196, 222, 255, "", 0, "Last update: 7.12.2020")
end)

